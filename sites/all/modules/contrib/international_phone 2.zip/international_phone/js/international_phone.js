(function ($) {

  Drupal.behaviors.international_phone = {
    attach: function (context, settings) {
      $(".international_phone-number").intlTelInput({
        //utilsScript: "/sites/all/modules/contrib/international_phone/js/utils.js",
        defaultCountry: "th",
        preferredCountries: [ "us", "gb" , "th"],
        //hiddenInput: "full_field_in_contact_number[]",
        nationalMode: true,
        


      });
    }
  };

}(jQuery));
