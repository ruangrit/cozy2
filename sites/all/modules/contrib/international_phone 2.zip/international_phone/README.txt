INTERNATIONAL PHONE FIELD
-------------------------

DESCRIPTION
-----------
This module provides a international phone field type for CCK.

PREREQUISITES
-------------
The international_phone.module requires the content.module to be installed.

INSTALLATION
------------
To install, copy the international_phone directory and all its contents to your
modules directory.

CONFIGURATION
-------------
To enable this module, visit administer -> modules, and enable phone.

Todo List:
----------
* add the validation of phone numbers for the different countries

Author
------
Mayur Jadhav

If you use this module, find it useful, and want to send the author
a thank you note, then use the Feedback/Contact page at the URL above.

The author can also be contacted for paid customizations of this
and other modules.
